//import the package
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code="CalcGridLayoutDemo.class" width=400 height=400>
</applet>
*/

public class CalcGridLayoutDemo extends Applet
{
	int c=0;
	public void init()
	{
		setLayout(new GridLayout(5,4));
		for(int i=0;i<=9;i++)
		{		
						
			add(new Button(""+c));
			c++;
			
		}
		Button b1=new Button("+");
		add(b1);
		Button b2=new Button("-");
		add(b2);
		Button b3=new Button("*");
		add(b3);
		Button b4=new Button("/");	
		add(b4);
		Button b5=new Button("=");
		add(b5);
		Button bClear=new Button("clear");
		add(bClear);
	}
}		