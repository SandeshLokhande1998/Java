//PrepStmtDemo.java
import java.sql.*;

public class PrepStmtDemo
{
    static Connection con;
    static Statement stmt;
    static PreparedStatement ps;
    static ResultSet rs;

    public static void main(String[] args)
    {
        String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
        String url = "jdbc:odbc:javadb";
        String insertQuery = "INSERT INTO student VALUES (?, ?, ?)";
        Scanner sc = new Scanner(System.in);
        try
        {
            Class.forName(driver);
            con = DriverManager.getConnection(url);
            stmt = con.createStatement();
            ps = con.prepareStatement(insertQuery);
            showTable();
            for (int i=1; i<=5; i++)
            {
                System.out.println("Enter Roll No, Student Name and Class: ");
                ps.setInt(1, sc.nextInt());
                ps.setString(2, sc.nextString());
                ps.setString(3, sc.setString());
                ps.executeUpdate();
            }
            System.out.println("Rows Affected: " + count);
            showTable();
            con.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void showTable() throws SQLException
    {
        rs = stmt.executeQuery("SELECT * FROM student");
        System.out.println("\n+---------+------------+-------+");
        System.out.printf("| %7s | %10s | %5s |\n","Roll No", "Name", "Class");
        System.out.println("+---------+------------+-------+");
        while (rs.next())
        {
            int rn = rs.getInt(1);
            String sn = rs.getString(2);
            String sc = rs.getString(3);
            System.out.printf("| %7d | %-10s | %-5s |\n",rn, sn, sc);
        }
        System.out.println("+---------+------------+-------+\n");
    }
}
