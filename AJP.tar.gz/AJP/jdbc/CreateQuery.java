//CreateQuery.java
import java.sql.*;

public class CreateQuery
{
    static Connection con;
    static Statement stmt;
    static ResultSet rs;

    public static void main(String[] args)
    {
        String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
        String url = "jdbc:odbc:javadb";
        String createQuery = "CREATE TABLE student (rollno NUMBER(4) PRIMARY KEY, stud_name VARCHAR(50), stud_class VARCHAR(4))";
        try
        {
            Class.forName(driver);
            con = DriverManager.getConnection(url);
            stmt = con.createStatement();
            int count = stmt.executeUpdate(createQuery);
            System.out.println("Table created!");
            showTable();
            con.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void showTable() throws SQLException
    {
        rs = stmt.executeQuery("SELECT * FROM student");
        System.out.println("\n+---------+------------+-------+");
        System.out.printf("| %7s | %10s | %5s |\n","Roll No", "Name", "Class");
        System.out.println("+---------+------------+-------+");
        while (rs.next())
        {
            int rn = rs.getInt(1);
            String sn = rs.getString(2);
            String sc = rs.getString(3);
            System.out.printf("| %7d | %-10s | %-5s |\n",rn, sn, sc);
        }
        System.out.println("+---------+------------+-------+\n");
    }
}
