//Program to insert data into table

import java.sql.Connection;
import java.sql.Statement;

public class JDBCDemo
{
    static String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    static String url = "jdbc:odbc:JavaDB";
    static String insertQuery = "";

    static Connection con;
    static Statement stmt;
    static ResultSet rs;
    public static void main(String[] args)
    {
        try
        {
            Class.forName(driver);
            System.out.println("Driver Loaded!");
            con = DriverManager.getConnection(url);
            System.out.println("Connection established!");
            stmt = con.createStatement();
            System.out.println("Statement created!");
            //int count = stmt.executeUpdate(insertQuery);
            con.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}
