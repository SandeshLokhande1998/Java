//InsertQuery.java
import java.sql.*;

public class InsertQuery
{
    static Connection con;
    static Statement stmt;
    static ResultSet rs;

    public static void main(String[] args)
    {
        String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
        String url = "jdbc:odbc:javadb";
        String insertQuery = "INSERT INTO student VALUES (123, 'ABC', 'CO6G')";
        try
        {
            Class.forName(driver);
            con = DriverManager.getConnection(url);
            stmt = con.createStatement();
            showTable();
            int count = stmt.executeUpdate(insertQuery);
            System.out.println("Rows Affected: " + count);
            showTable();
            con.close();
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void showTable() throws SQLException
    {
        rs = stmt.executeQuery("SELECT * FROM student");
        System.out.println("\n+---------+------------+-------+");
        System.out.printf("| %7s | %10s | %5s |\n","Roll No", "Name", "Class");
        System.out.println("+---------+------------+-------+");
        while (rs.next())
        {
            int rn = rs.getInt(1);
            String sn = rs.getString(2);
            String sc = rs.getString(3);
            System.out.printf("| %7d | %-10s | %-5s |\n",rn, sn, sc);
        }
        System.out.println("+---------+------------+-------+\n");
    }
}
