import java.awt.*;
import java.applet.*;


/*<apllet code="CheckboxDemo.class" width=400 height=400 >
</applet>
*/

public class CheckboxDemo extends Applet
{	// declaring awt components
	Checkbox chk1,chk2,chk3,chk4;
	CheckboxGroup cbg;

	public void init()
	{
		chk1=new Checkbox("AJP");
		chk1=new Checkbox("ST");
		cbg=new CheckboxGroup();		
		chk1=new Checkbox("AJP",true,cbg);
		chk1=new Checkbox("ST",false,cbg);
		Label lsub=new Label("Subjects:");

		add(chk1);
		add(chk2);
		add(lsub);
		add(chk3);
		add(chk4);


	}
}
