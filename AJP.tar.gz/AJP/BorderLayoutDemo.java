//import the package
import java.awt.*;
import java.applet.*;

/*<applet code="BorderLayoutDemo.class" width=400 height=400>
</applet>
*/

public class BorderLayoutDemo extends Applet
{
	Button bNorth,bSouth,bEast,bWest;
	TextArea txtmsg;

	public void init()
	{
		
		setLayout(new BorderLayout());
		bNorth=new Button("north");
		add(bNorth,BorderLayout.NORTH);

		bSouth=new Button("south");
		add(bSouth,BorderLayout.SOUTH);
		
		bEast=new Button("east");
		add(bEast,BorderLayout.EAST);
		
		bWest=new Button("west");
		add(bWest,BorderLayout.WEST);
		
		String msg="This the borderlayout demo";
		txtmsg= new TextArea(msg);
		add(txtmsg,BorderLayout.CENTER);
	}
}		