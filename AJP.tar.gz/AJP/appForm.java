import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code=appForm.java width=400 height=400>
</applet>
*/

public class appForm extends Applet
{
	Label lFirstname,lLastname,lGender,lAge,lUsername,lInterest,lPassword;
	Button bSubmit;
	TextField tFirstname,tLastname,tUsername,tPassword;
	Checkbox chkMale,chkFemale,chkCo,chkAutoMobile,chkEntertainment,chkLifestyle;
	CheckboxGroup cbg;
	Choice cAge;

	public void init()
	{	setLayout(new FlowLayout());
		//Firstname
      		lFirstname=new Label("First Name:",Label.LEFT);
		tFirstname=new TextField(30);
		add(lFirstname);
		add(tFirstname);

		//Lastname
		lLastname=new Label("Last Name:",Label.LEFT);
		tLastname=new TextField(30);
		add(lLastname);
		add(tLastname);

		//Gender
		lGender= new Label("Gender",Label.LEFT);
		add(lGender);
		cbg=new CheckboxGroup();
		chkMale=new Checkbox("Male",cbg,true);
		chkFemale=new Checkbox("Female",cbg,false);
		//add(cbg);
		add(chkMale);
		add(chkFemale);

		//Age
		lAge=new Label("Age",Label.LEFT);
		cAge=new Choice();
		for(int i=1;i<=100;i++)
			cAge.add(Integer.toString(i));
		add(lAge);
		add(cAge);

		//username
		lUsername=new Label("Username");
		tUsername=new TextField(20);
		add(lUsername);
		add(tUsername);

		//password
		lPassword=new Label("password:");
		tPassword=new TextField(20);
		tPassword.setEchoChar('*');
		add(lPassword);
		add(tPassword);

		//Interest
		lInterest=new Label("Interest:");
		
		chkCo=new Checkbox("Co");
		chkAutoMobile=new Checkbox("AutoMobile");
		chkEntertainment=new Checkbox("Entertainment");
		chkLifestyle=new Checkbox("Lifestyle");

		add(lInterest);
		add(chkCo);
		add(chkAutoMobile);
		add(chkEntertainment);
		add(chkLifestyle);
		
		bSubmit=new Button("Submit");
		add(bSubmit);

	}
}