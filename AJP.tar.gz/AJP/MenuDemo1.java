import java.awt.*;
import java.awt.event.*;

public class MenuDemo1 extends Frame
{
	public static void main(String args[])
	{
		//MenuDemo m=new MenuDemo();
		setVisible(true);
		
		MenuBar mbar=new MenuBar();
		setMenuBar(mbar);
		
		//creating menus 
			
		Menu Picture=new Menu("Picture");
		Menu Home=new Menu("Home");
		
		//adding menus to menubar
		
		mbar.add(Home);
		mbar.add(Picture);
		
		//creating menu item for Home
		
		MenuItem Paste=new MenuItem("Paste");
		CheckboxMenuItem Insert=new CheckboxMenuItem("Insert Picture");
		
		//adding menu items to menu
			
		Home.add(Paste);
		Picture.add(Insert);
		
		
	}
}
		 
