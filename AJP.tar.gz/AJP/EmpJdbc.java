//1.import the package
import java.sql.*;

public class EmpJdbc
{
	public static void main(String args[])
	{
	  try
	  {
		//2.register the driver 
		  class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		//3.Establish the connection
		 Connection con=DriverManager.getConnection("jdbc:odbc:EmpDSN");
		//4.Create the Statement
		 Statement stmt=con.createStatement();
		//5.Execute the query
		 int c1=stmt.executeUpdate("create table employee(emp_id int,emp_name varchar(20)");
			System.out.println("After Creation:");
			Resultset rs=stmt.executeQuery("select *from employee");
			System.out,println("emp_id"+"     "+"emp_name");
			while(rs.next())
			{
				int eid=rs.getInt("emp_id");
				String ename=rs.getString("emp_name");
				System.out,println(eid+"     " +ename);
			}
		//6.close the connection
			con.close();
	      }//end of try
	      catch(Exception e)
	      {	
	      }//end of catch
	}//end of main()
}//end of EmpJdbc
	