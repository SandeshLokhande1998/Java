//import the package
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code="FlowLayoutDemo.class" width=400 height=400>
</applet>
*/

public class FlowLayoutDemo extends Applet
{
	Button bOK,bCancel;
	Label lUsername,lPassword;
	public void init()
	{
		setLayout(new FlowLayout(FlowLayout.CENTER));
	
		lUsername=new Label("USERNAME:",Label.LEFT);
		TextField tUsername=new TextField(20);
		add(lUsername);
		add(tUsername);

		lPassword=new Label("PASSWORD:",Label.LEFT);
                TextField tPassword=new TextField(20);
		add(lPassword);
		add(tPassword);
		
		bOK=new Button("OK");
		bCancel=new Button("Cancel");
		add(bOK);	
		add(bCancel);
	}
}		