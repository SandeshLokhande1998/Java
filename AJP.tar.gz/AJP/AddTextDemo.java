//import the package
import java.awt.*;
import java.applet.*;

/*<applet code="AddTextDemo.class" width=400 height=400>
</applet>
*/

public class AddTextDemo extends Applet implements ActionListener
{
	Label l1,l2,l3;
	TextField txt1,txt2,txt3;
	Button b1;
	String msg="";
	int n1,n2;
	public void init()
	{
		l1=new Label("Enter number in TextField");
		txt1=new TextField(12);
		add(l1);
		add(txt1);

		l2=new Label("Enter number in TextField");
		txt2=new TextField(12);
		add(l2);
		add(txt2);

		l3=new Label("Enter number in TextField");
		txt3=new TextField(12);	
		add(l3);
		add(txt3);
		
		b1=new Button("add");	
		add(b1);	
		b1.addActionListener(this);
          }		
	public void actionPerformed(ActionEvent ae)
	{
		n1=Integer.parseInt(txt1.getText());
		n2=Integer.parseInt(txt2.getText());
		int ans;
		if(ae.getSource()==b1)
		{	
			ans=n1+n2;
			txt3.setText(Integer.toString(ans));
		}
	}
}