import java.awt.*;
import java.applet.*;


/*<apllet code="RegistrationDemo.class" width=400 height=400 >
</applet>
*/

public class RegistrationDemo extends Applet
{	// declaring awt components
	Button bSubmit;
	TextField tFirstName,tMiddleName,tSurName;
	TextArea tAddress;
	Label lStuddetails,lFirstName,lMiddleName,lSurName;
	Label lGender,lCourse,lSemester,lPlace,lAddress;
	choice cCourse,cSem;
	List lsPlace;
	Checkbox chkMale,chkFemale;
	CheckboxGroup cbg;
	public void init()
	{
		//creating awt components
		lStuddetails=new Label("Student Details:",Label.CENTER);
		lFirstName=new Label("First Name:",Label.LEFT);
		lLastName=new Label("Last Name:",Label.LEFT);
		lMiddleNAme=new Label("Middle Name:",Label.LEFT);
		lSurNAme=new Label("SurName:",Label.LEFT);
		lGender=new Label("Gender:",Label.LEFT);
		lCourse=new Label("Course:",Label.LEFT);
		lSemster=new Label("Sem:",Label.LEFT);
		lPlace=new Label("Place:",Label.LEFT);
		lAddress=new Label("Address:",Label.LEFT);
		
		tFirstName=new TextField(15);
		tLastName=new TextField(15);
		tSurName=new TextField(15);

		tAddress=new TextArea("",5,30,TextArea.SCROLLBARS_BOTH);

		cCourse=new Choice();
		cSem=new Choice();

		lsPlace=new List();

		cbg=new CheckboxGroup();
		chkMale=new Checkbox("Male",true,cbg);
		chkMale=new Checkbox("Male",false,cbg);

		bSubmit=new Button("Submit");

		//Adding the components on the applet
		add(lFirstName);
		add(tFirstName);
		add(lMiddleName);	
	        add(tMiddleName);
		add(lSurName);
		add(tSurName);
		add(lAddress);
		add(tAddress);
		add(lGender);
		add(chkMale);
		add(chkFemale);
		add(lCourse);
		
		cCourse.add("CO");
		cCourse.add("ETE");
		cCourse.add("EX");
		cCourse.add("CE");
		cCourse.add("ME");
		cCourse.add("IT");

		add(cCourse);
		add(lSemester);
		cSem.add("1");
		cSem.add("2");
		cSem.add("3");
		cSem.add("4");
		cSem.add("5");

		add(cSem);
		add(lPlace);
		lsPlace.add("Latur");
		lsPlace.add("Pune");
		lsPlace.add("Nashik");
		lsPlace.add("Satara");
		add(lPlace);
		add(bSubmit);
	}//end of init()
}//end of class Registration demo


	

