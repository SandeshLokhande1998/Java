//import the package
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code="GridLayoutDemo.class" width=400 height=400>
</applet>
*/

public class GridLayoutDemo extends Applet
{
	int c=1;
	public void init()
	{
		setLayout(new GridLayout(4,2));
		for(int i=1;i<4;i++)
		{		
			for(int j=1;j<4;j++)				
			{	
				add(new Button(""+c));
				c++;
			}
		}

	}
}		