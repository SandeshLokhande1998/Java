//import the package
import java.awt.*;
import java.applet.*;

/*<applet code="CardLayoutDemo.class" width=400 height=400>
</applet>
*/

public class CardLayoutDemo extends Applet
{
	Checkbox chWin98,chWin2000,chLinux,chAndroid;
	Button bWin,bOther;
	Panel Winos,Otheros,osCard;

	public void init()
	{
		bWin=new Button("Windows");
		add(bWin);
		bOther=new Button("Others");
		add(bOther);
		CardLayout clay=new CardLayout();
		
		osCard=new Panel();
		osCard.setLayout(clay);
		
		Winos=new Panel();
		chWin98=new Checkbox("win98");
		chWin2000=new Checkbox("win2000");
		Winos.add(chWin98);
		Winos.add(chWin2000);

		Otheros=new Panel();
		chLinux=new Checkbox("Linux");
		chAndroid=new Checkbox("Android");
		Otheros.add(chLinux);
		Otheros.add(chAndroid);

		osCard.add(Winos,"Window");
		osCard.add(Otheros,"Android");
	}
}
		
		
			