class Base
{
	int a,b,c;
	void getData(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	void show()
	{
		System.out.println("I am Base\n");
	}	
}
class Derived extends Base
{
	int c;
	void getDataDerived(int c)
	{
		this.c=c;
	}
	void show()
	{
		System.out.println("I am Derived");
	}
}
class BaseDerivedDemo
{
	public static void main(String[] args)
	{
		Derived d1;
		Base b1 = new Base();
		d1=b1;
		d1.show();
	}
}
