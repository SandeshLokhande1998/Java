//1.importr the package
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*
<applet code="MenuDemo.class" width=400 height=400>
</applet>
*/

class MenuFrame extends Frame implements ActionListener
{
	String msg;
	MenuBar mbar;
	MenuItem mNew,mOpen,mSave,mExit;
	Menu mFile,mEdit;
	MenuItem mCut,mCopy,mPaste;
	MenuFrame(String t)
	{
		super(t);
		//create menubar and add it to frame
		mbar=new MenuBar();
		setMenuBar(mbar);
		
		//create menu and menuItems
		mFile=new Menu("File");
		mNew=new MenuItem("New");
		mOpen=new MenuItem("Open");
		mSave=new MenuItem("Save");
		mExit=new MenuItem("Exit");
		mFile.add(mNew);
		mFile.add(mOpen);
		mFile.add(mSave);
		mFile.add(mExit);

		//create menu and menuitems
		mEdit=new Menu("edit");	
		mCut=new MenuItem("cut");
		mCopy=new MenuItem("copy");
		mPaste=new MenuItem("paste");

		mEdit.add(mCut);
		mEdit.add(mCopy);
		mEdit.add(mPaste);
		
		//add menu to menubar
		mbar.add(mFile);
		mbar.add(mEdit);

		mNew.addActionListener(this);
		mOpen.addActionListener(this);
		mSave.addActionListener(this);
		mExit.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str=ae.getActionCommand();
		msg="You click on"+str+"Menu Item";
		repaint();
	}
	public void paint(Graphics g)
	{
		g.drawString(msg,60,100);
	}
}
public class MenuDemo extends Applet
{
	Frame f;
	public void init()
	{
		f=new MenuFrame("MenuDemo");
		f.setSize(500,500);
		f.setVisible(true);
	}
	public void start()
	{
	f.setVisible(true);
	}
	public void stop()
	{
	f.setVisible(false);
	}
}

