import jav.awt.*;
import java.applet.*;

/*<applet code="ScrollbarDemo"width=400 height=400>
</applet>
*/
public class ScrollbarDemo extends Applet
{
	Scrollbar bar=new Scrollbar(Scrollbar.VERTICAL,80,0,1,100);
	public void init()
	{
		add(bar);
	}
}