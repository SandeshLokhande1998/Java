
import java.awt.*;
import java.applet.*;
/*<applet code="LayoutDemo.java" width=400 height=400>
</applet>
*/
public class LayoutDemo extends Applet
{
	Button bOK,bCancel,bExit;
	FlowLayout f1;
	public void init()
	{
		bOK=new Button("OK");
		bCancel=new Button("Cancel");
		bExit=new Button("Exit");
		
		f1=new FlowLayout(FlowLayout.RIGHT);
		setLayout(f1);
		add(bOK);
		add(bCancel);
		add(bExit);	
	}
}